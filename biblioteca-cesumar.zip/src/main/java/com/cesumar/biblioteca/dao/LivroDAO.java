package com.cesumar.biblioteca.dao;

import com.cesumar.biblioteca.model.Livro;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class LivroDAO {
    private static final List<Livro> livros = new ArrayList<>();
    private static final AtomicInteger idCounter = new AtomicInteger(1);

    public static List<Livro> listar() {
        return livros;
    }

    public static void adicionar(Livro livro) {
        livro.setId(idCounter.getAndIncrement());
        livros.add(livro);
    }

    public static boolean removerPorId(int id) {
        return livros.removeIf(l -> l.getId() == id);
    }

    public static boolean removerPorIsbn(String isbn) {
        return livros.removeIf(l -> l.getIsbn().equalsIgnoreCase(isbn));
    }
}
