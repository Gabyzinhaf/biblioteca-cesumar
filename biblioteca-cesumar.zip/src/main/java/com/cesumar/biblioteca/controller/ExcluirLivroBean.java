package com.cesumar.biblioteca.controller;

import com.cesumar.biblioteca.dao.LivroDAO;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.context.FacesContext;

@ManagedBean
public class ExcluirLivroBean {
    private String isbn;
    private String mensagem;

    public String getIsbn() {
        return isbn;
    }
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void excluir() {
        boolean removido = LivroDAO.removerPorIsbn(isbn);
        if (removido) {
            mensagem = "Livro com ISBN " + isbn + " removido com sucesso!";
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, mensagem, null));
        } else {
            mensagem = "Livro não encontrado para o ISBN: " + isbn;
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, mensagem, null));
        }
        isbn = null;
    }
}
