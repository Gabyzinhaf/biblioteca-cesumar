package com.cesumar.biblioteca.controller;

import com.cesumar.biblioteca.dao.LivroDAO;
import com.cesumar.biblioteca.model.Livro;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/livros")
public class LivroServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String acao = request.getParameter("acao");

        if ("listar".equals(acao)) {
            request.setAttribute("livros", LivroDAO.listar());
            request.getRequestDispatcher("listarLivros.jsp").forward(request, response);

        } else if ("excluir".equals(acao)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                try {
                    int id = Integer.parseInt(idStr);
                    LivroDAO.removerPorId(id);
                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "ID inválido para exclusão.");
                }
            } else {
                String isbn = request.getParameter("isbn");
                if (isbn != null && !isbn.isEmpty()) {
                    LivroDAO.removerPorIsbn(isbn);
                }
            }
            response.sendRedirect("livros?acao=listar");

        } else if ("cadastrar".equals(acao)) {
            request.getRequestDispatcher("cadastrarLivro.jsp").forward(request, response);
        } else {
            response.sendRedirect("livros?acao=listar");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String titulo = request.getParameter("titulo");
        String autor = request.getParameter("autor");
        String anoStr = request.getParameter("anoPublicacao");
        String isbn = request.getParameter("isbn");

        String erro = null;

        if (titulo == null || titulo.trim().isEmpty() ||
            autor == null || autor.trim().isEmpty() ||
            anoStr == null || anoStr.trim().isEmpty() ||
            isbn == null || isbn.trim().isEmpty()) {
            erro = "Todos os campos são obrigatórios.";
        }

        int ano = 0;
        if (erro == null) {
            try {
                ano = Integer.parseInt(anoStr);
            } catch (NumberFormatException e) {
                erro = "Ano de publicação inválido.";
            }
        }

        if (erro == null) {
            if (!(isbn.matches("\\d{10}") || isbn.matches("\\d{13}"))) {
                erro = "ISBN deve conter 10 ou 13 dígitos numéricos.";
            }
        }

        if (erro != null) {
            request.setAttribute("erro", erro);
            request.getRequestDispatcher("cadastrarLivro.jsp").forward(request, response);
            return;
        }

        Livro livro = new Livro();
        livro.setTitulo(titulo);
        livro.setAutor(autor);
        livro.setAnoPublicacao(ano);
        livro.setIsbn(isbn);

        LivroDAO.adicionar(livro);

        response.sendRedirect("livros?acao=listar");
    }
}
